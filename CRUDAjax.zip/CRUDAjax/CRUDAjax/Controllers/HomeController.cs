﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CRUDAjax.Models;

namespace CRUDAjax.Controllers
{
    public class HomeController : Controller
    {
        EmployeeDB empDB = new EmployeeDB();
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult List()
        {
            return Json(empDB.ListAll(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult Add(Employee emp)
        {
            return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetbyID(int ID)
        {
            var Employee = empDB.ListAll().Find(x => x.EmployeeID.Equals(ID));
            return Json(Employee, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Update(Employee emp)
        {
            return Json(empDB.Update(emp), JsonRequestBehavior.AllowGet);
        }
        public JsonResult Delete(int ID)
        {
            return Json(empDB.Delete(ID), JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [ActionName("GetEmployeeAll")]
        public JsonResult  GetEmpAll()
        
        {
            //return listEmp.First(e => e.ID == id);
            SqlDataReader reader = null;
            SqlConnection myConnection = new SqlConnection();
            // myConnection.ConnectionString = @"Server=.\SQLSERVER2008R2;Database=EmployeeDB;User ID=sa;Password=sa;";
            myConnection.ConnectionString = "Server=localhost;Database=EmployeeDB;Trusted_Connection=True;MultipleActiveResultSets=true";
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "Select * from Employee With (Nolock) where IsSoftDelete is  NULL ";
            sqlCmd.Connection = myConnection;
            myConnection.Open();
            reader = sqlCmd.ExecuteReader();
            List<Employee> lst = new List<Employee>();
            Employee emp = null;
            while (reader.Read())
            {
                emp = new Employee();
                emp.EmployeeID = Convert.ToInt16(reader["EmpId"]);
                emp.Name = Convert.ToString(reader["Name"]);
                emp.Age = Convert.ToInt16(reader["Age"]);
                emp.Country = Convert.ToString(reader["Country"]);
                emp.State = Convert.ToString(reader["State"]);
                //emp.Address = Convert.ToString(reader["Address"]);
                //emp.Email = Convert.ToString(reader["Email"]);
                ////  emp.Phone = Convert.ToString(reader["Phone"]);
                //emp.Address = Convert.ToString(reader["Address"]);
                lst.Add(emp);
                // emp.ManagerId = Convert.ToInt32(reader.GetValue(2));
            }
            
            return Json(lst.ToList(), JsonRequestBehavior.AllowGet); ;
            myConnection.Close();
        }


    }
}