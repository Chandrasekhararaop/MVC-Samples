﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace CRUDAjax.Models
{
    public class EmployeeDB
    {
        //declare connection string
        string cs = ConfigurationManager.ConnectionStrings["EFDbContext"].ConnectionString;

        //Return list of all Employees
        public List<Employee> ListAll()
        {
            List<Employee> lst = new List<Employee>();
            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = "Server=localhost;Database=EmployeeDB;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection con=new SqlConnection(myConnection.ConnectionString))
            {
                con.Open();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "Select * from Employee ";
                sqlCmd.Connection = myConnection;
                myConnection.Open();

                SqlDataReader reader = sqlCmd.ExecuteReader();
               // List<Employee> lst = new List<Employee>();
                Employee emp = null;
                while (reader.Read())
                {
                    emp = new Employee();
                    emp.EmployeeID = Convert.ToInt16(reader["EmpId"]);
                    emp.Name = Convert.ToString(reader["Name"]);
                    emp.Age = Convert.ToInt16(reader["Age"]);
                    emp.Country = Convert.ToString(reader["Country"]);
                    emp.State = Convert.ToString(reader["State"]);
                    //emp.Address = Convert.ToString(reader["Address"]);
                    //emp.Email = Convert.ToString(reader["Email"]);
                    ////  emp.Phone = Convert.ToString(reader["Phone"]);
                    //emp.Address = Convert.ToString(reader["Address"]);
                    lst.Add(emp);
                    // emp.ManagerId = Convert.ToInt32(reader.GetValue(2));
                }
                // com.CommandType = CommandType.StoredProcedure;
                //SqlDataReader rdr = com.ExecuteReader();
                //while(rdr.Read())
                //{
                //    lst.Add(new Employee { 
                //        EmployeeID=Convert.ToInt32(rdr["EmployeeId"]),
                //        Name=rdr["Name"].ToString(),
                //        Age = Convert.ToInt32(rdr["Age"]),
                //        State = rdr["State"].ToString(),
                //        Country = rdr["Country"].ToString(),
                //    });
                //}
                return lst;
            }
        }

        //Method for Adding an Employee
        public int Add(Employee emp)
        {
            int rowInserted;
            SqlConnection myConnection = new SqlConnection();
            // myConnection.ConnectionString = @"Server=.\SQLSERVER2008R2;Database=EmployeeDB;User ID=sa;Password=sa;";
            myConnection.ConnectionString = "Server=localhost;Database=EmployeeDB;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection con=new SqlConnection(myConnection.ConnectionString))
            {
                con.Open();
         
                SqlCommand com = new SqlCommand();
                com.CommandType = CommandType.Text;
                com.CommandText = "INSERT INTO Employee (Name,Age,State,Country) Values (@Name,@Age,@State,@Country)";
                com.Connection = myConnection;


              //  com.Parameters.AddWithValue("@Id", emp.EmployeeID);
                com.Parameters.AddWithValue("@Name", emp.Name);
                com.Parameters.AddWithValue("@Age", emp.Age);
                com.Parameters.AddWithValue("@State", emp.State);
                com.Parameters.AddWithValue("@Country", emp.Country);
                //com.Parameters.AddWithValue("@Address", emp.Address);
               // com.Parameters.AddWithValue("@Action", "Insert");

                myConnection.Open();
                rowInserted = com.ExecuteNonQuery();
                myConnection.Close();

            }
            return rowInserted;
        }

        //Method for Updating Employee record
        public int Update(Employee emp)
        {
            int rowInserted;
            SqlConnection myConnection = new SqlConnection();
            
            myConnection.ConnectionString = "Server=localhost;Database=EmployeeDB;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection con = new SqlConnection(myConnection.ConnectionString))
            {
                con.Open();
               

               
                SqlCommand com = new SqlCommand();
                com.CommandType = CommandType.Text;

                
                com.CommandText= "Update Employee Set Name=@Name,Age=@Age,State=@State,Country=@Country Where EmpId=@Id";
                //com.CommandText= "Update Employee set Name=@Name,Age=@Age,State=@State,Country=@Country where EmpId=@@Id"
               // com.CommandText = "INSERT INTO Employee (Name,Age,State,Country) Values (@Name,@Age,@State,@Country)";
                com.Connection = myConnection;


                com.Parameters.AddWithValue("@Id", emp.EmployeeID);
                com.Parameters.AddWithValue("@Name", emp.Name);
                com.Parameters.AddWithValue("@Age", emp.Age);
                com.Parameters.AddWithValue("@State", emp.State);
                com.Parameters.AddWithValue("@Country", emp.Country);

                myConnection.Open();
               
                rowInserted = com.ExecuteNonQuery();
              
                myConnection.Close();

            }
            return rowInserted;
        }

        //Method for Deleting an Employee
        public int Delete(int ID)
        {
            int i;
            SqlConnection myConnection = new SqlConnection();
            myConnection.ConnectionString = "Server=localhost;Database=EmployeeDB;Trusted_Connection=True;MultipleActiveResultSets=true";
            using (SqlConnection con = new SqlConnection(myConnection.ConnectionString))
            {
                con.Open();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                // sqlCmd.CommandText = "delete from Employee where EmpId=" + ID + "";
                sqlCmd.CommandText = "Update Employee Set IsSoftDelete=@IsSoftDelete where EmpId=@Id";
                sqlCmd.Parameters.AddWithValue("@Id", ID);
                sqlCmd.Parameters.AddWithValue("@IsSoftDelete", "true");

                sqlCmd.Connection = myConnection;
                 myConnection.Open();//IsSoftDelete
                int rowDeleted = sqlCmd.ExecuteNonQuery();
                i = sqlCmd.ExecuteNonQuery();
            }
            return i;
        }
    }
}
